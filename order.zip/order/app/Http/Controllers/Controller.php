<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use GuzzleHttp\Client;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

     public function buy(Request $request)
     {    
         $client = new Client();
         $response = $client->request('POST', 'http://127.0.0.1:3030/buy', [
             'form_params' => [
                 'id' => $request->id,
             ]
     ]);
	 echo $response->getBody(); 
     }
}
<?php

namespace App\Http\Controllers;


use GuzzleHttp\Client;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Ixudra\Curl\Facades\Curl;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function search(Request $request) {
        $client = new Client();
        try
        {
        $response = $client->request('GET', 'http://127.0.0.1:3030/search?topic='.$request->input('topic'));
        echo $response->getBody();
        }
        catch (GuzzleHttp\Exception\ServerException $e) {
            echo ($e.getResponse()->getBody()->getContents());
        }
    }

    public function lookUp(Request $request) {
        $client = new Client();
        $response = $client->request('GET', 'http://127.0.0.1:3030/lookup?id='.$request->input('id'));
        echo $response->getBody();
    }

    public function buy(Request $request) {
        $client = new Client();
        $response = $client->request('POST', 'http:/127.0.0.1:6060/buy', [
            'form_params' => [
                'id' => $request->input('id'),
            ]
        ]);
        echo $response->getBody();
    }
}
